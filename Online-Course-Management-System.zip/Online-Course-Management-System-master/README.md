run node app.js
